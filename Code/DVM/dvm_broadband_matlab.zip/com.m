
function w = com(N, alpha)
% Compute coefficients of polynomial p(z) = (z - 1)(z - alpha^2)...(z - alpha^(N-2))

N1 = N / 2;
w_prev = [1; zeros(N1-1, 1)];

for k = 1:N1-1
    alpha_pow = alpha^(2*(k-1));
    Z = diag(ones(N1-2,1), -1);
    Z(end+1, :) = [zeros(1,N1-2), 1];
    e = [zeros(N1-2,1); 1];
    O = zeros(N1-1, 1);
    T = [Z, O; e.', 0] - alpha_pow * eye(N1);
    w_prev = T * [w_prev; 0];
end

w = w_prev(1:N1);
end
